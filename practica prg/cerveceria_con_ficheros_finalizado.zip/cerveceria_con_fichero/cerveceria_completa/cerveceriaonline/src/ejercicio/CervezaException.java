package ejercicio;

public class CervezaException extends RuntimeException{
    public CervezaException(String mensaje){
        super(mensaje);
    }
}
